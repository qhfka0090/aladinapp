import { useState, useEffect, useCallback, useMemo } from 'react';
import { useParams, useNavigate, useLocation } from 'react-router-dom';
import { useDispatch } from 'react-redux';
import { addToCart } from '../features/cartSlice';
import { calculateItemTotal, validateCartItem } from '../utils/cartUtils';



function Product(){
    const {id} = useParams();
    const navigate = useNavigate();
    const dispatch = useDispatch();
    const location = useLocation();
    const [ quantity, setQuantity ] = useState(1);
    const [ product, setProduct ] = useState({images:[]});
    
    useEffect(()=>{
        console.log( location.pathname, location.state );
        if( location.state && location.state.product ){ 
            setProduct(location.state.product); 
        }else{
            console.log('제품 데이터 가져오는 중...');
        }
    },[location, id]) 

    const handleQuantityChange = useCallback((change)=>{
        setQuantity(prevquantity=>Math.max(1,prevquantity+change));
    },[]);

    const totalPrice = useMemo(()=>{
        return product ? calculateItemTotal({...product, quantity}) : 0
    },[product, quantity]) 


    const handleAddCart = useCallback(()=>{
        if(!product){ return; }

        const cartItem = { 
            id: id,
            name: product.title,
            price: product.discountPrice || product.price,
            quantity: quantity,
            image: product.images,
        }

        try{
            validateCartItem(cartItem); 
            dispatch(addToCart(cartItem)); 
            alert('제품정보를 장바구니에 전달 성공') 
            navigate('/cart'); 
        }catch(err){
            console.error('유효성 검사 에러', err.message);
        }
    },[dispatch, product, id, quantity, navigate]);

    if(!product){
        return <div>제품데이터 없음</div>
    }


    return(
        <div className='product'>
            <div className='product-images'>
                {
                    product.images?.map((img)=>(
                        <div className='img-box' key={img.id}>
                            <img src={img} alt={img.title} />
                        </div>
                    ))
                }
            </div>
            <div className='product-info'>
                <h2>{product.title}</h2>
                <div className='price'>
                    <span className='original-price'>{product.price.toLocaleString()}원</span>
                    <span className='discount-price'>혜택가격 : 
                        {
                        product.discountPrice ? product.discountPrice.toLocaleString() : product.price.toLocaleString()
                        }
                        원
                    </span>
                </div>
                <div className='quantity-selection'>
                    <h3>수량선택</h3>
                    <p>
                        <button onClick={()=>{handleQuantityChange(-1)}}> - </button>
                        <span>{ quantity } </span>
                        <button onClick={()=>{handleQuantityChange(1)}}> + </button>
                    </p>
                </div>
                <div className='total-proce'>
                    <h3>TOTAL</h3> : <span>{totalPrice.toLocaleString()}원</span>
                </div>
                <div className='action-buttons'>
                    <button className='buy-now'>즉시 구매</button>
                    <button className='add-to-cart' onClick={handleAddCart}>장바구니 담기</button>
                    <button className='wishlist'>위시리스트</button>
                </div>
            </div>
        </div>
    )
}
export default Product;
import { listItem } from "../contents/textdata";
import { Link } from 'react-router-dom';
import { ChevronDown, ChevronUp } from 'lucide-react';

function ListSection(){
    return(
        <section id='list'>
            <div className="list-top">
                <Link to=''>
                    <h3>7월 신용카드 무이자 안내</h3>
                    <ChevronUp className='right-icon' />
                </Link>
            </div>
            <div className="list-bottom">
                {
                    listItem.map((list,idx)=>(
                        <Link to={list.url} key={idx}>
                            <h4>{list.list}</h4>
                            <p>{list.title}</p>
                        </Link>
                    ))
                }
            </div>
        </section>
    )
}
export default ListSection;